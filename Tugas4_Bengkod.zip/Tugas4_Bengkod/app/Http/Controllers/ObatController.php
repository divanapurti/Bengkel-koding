<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Obat;

class ObatController extends Controller
{
    public function index()
    {
        $obats = Obat::all(); // harusnya ambil dari model Obat
        return view('list-obat', compact('obats'));
    }
}

