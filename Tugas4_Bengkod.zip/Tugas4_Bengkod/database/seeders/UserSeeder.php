<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            [
                'name' => 'Iqbal',
                'alamat' => 'Jl Imam Bonjol',
                'no_hp' => '090999099',
                'role' => 'dokter',
                'email' => 'iqbal@gmail.com',
                'password' => Hash::make('password'),
            ],
            [
                'name' => 'Neena',
                'alamat' => 'Jl Imam Bonjol',
                'no_hp' => '09087878',
                'role' => 'dokter',
                'email' => 'neena@gmail.com',
                'password' => Hash::make('password'),
            ],
            [
                'name' => 'Budi',
                'alamat' => 'Jl Imam Bonjol',
                'no_hp' => '09087822278',
                'role' => 'pasien',
                'email' => 'budi@gmail.com',
                'password' => Hash::make('password'),
            ],
            [
                'name' => 'Doremi',
                'alamat' => 'Jl Imam Bonjol 10',
                'no_hp' => '090878212278',
                'role' => 'pasien',
                'email' => 'doremi@gmail.com',
                'password' => Hash::make('password'),
            ],
            [
                'name' => 'Fasola',
                'alamat' => 'Jl Imam Bonjol 10',
                'no_hp' => '033878212278',
                'role' => 'pasien',
                'email' => 'fasola@gmail.com',
                'password' => Hash::make('password'),
            ],
        ];

        foreach ($data as $d) {
            User::create($d);
        }
    }
}
